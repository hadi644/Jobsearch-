
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

function Home() {
  return <h1>Selamat Datang di JobSearch</h1>;
}

function Login() {
  return (
    <div>
      <h2>Login</h2>
      <form>
        <input placeholder="Email" /><br />
        <input type="password" placeholder="Password" /><br />
        <button>Login</button>
      </form>
    </div>
  );
}

function Register() {
  return (
    <div>
      <h2>Pendaftaran</h2>
      <form>
        <input placeholder="Nama Lengkap" /><br />
        <input placeholder="Email" /><br />
        <input type="file" /><br />
        <button>Daftar</button>
      </form>
    </div>
  );
}

function App() {
  return (
    <Router>
      <nav>
        <Link to="/">Beranda</Link> | <Link to="/login">Login</Link> | <Link to="/daftar">Daftar</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/daftar" element={<Register />} />
      </Routes>
    </Router>
  );
}

export default App;
